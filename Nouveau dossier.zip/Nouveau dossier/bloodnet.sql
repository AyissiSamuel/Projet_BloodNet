--
-- PostgreSQL database dump
--

\restrict 9FjG3JnQZcOfjx3Bzy4TSLHuCBuo5fv9sgSachF3gvKDKlvH7oYs8idb8SDPLPg

-- Dumped from database version 18.4
-- Dumped by pg_dump version 18.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: core_identity; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA core_identity;


ALTER SCHEMA core_identity OWNER TO postgres;

--
-- Name: drone_telemetry; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA drone_telemetry;


ALTER SCHEMA drone_telemetry OWNER TO postgres;

--
-- Name: medical_logistics; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA medical_logistics;


ALTER SCHEMA medical_logistics OWNER TO postgres;

--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: utilisateurs; Type: TABLE; Schema: core_identity; Owner: postgres
--

CREATE TABLE core_identity.utilisateurs (
    id_utilisateur uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nom character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    mot_de_passe character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    statut_compte character varying(20) DEFAULT 'ACTIF'::character varying NOT NULL,
    id_hopital uuid,
    date_inscription timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_utilisateur_role CHECK (((role)::text = ANY (ARRAY[('SUPER_ADMIN'::character varying)::text, ('ADMIN_HOPITAL'::character varying)::text, ('PERSONNEL'::character varying)::text]))),
    CONSTRAINT chk_utilisateur_statut CHECK (((statut_compte)::text = ANY (ARRAY[('ACTIF'::character varying)::text, ('SUSPENDU'::character varying)::text])))
);


ALTER TABLE core_identity.utilisateurs OWNER TO postgres;

--
-- Name: commandes; Type: TABLE; Schema: drone_telemetry; Owner: postgres
--

CREATE TABLE drone_telemetry.commandes (
    id_commande uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    id_demandeur uuid NOT NULL,
    id_fournisseur uuid,
    groupe_sanguin character varying(3) NOT NULL,
    quantite integer DEFAULT 1 NOT NULL,
    statut_commande character varying(30) DEFAULT 'EN_ATTENTE'::character varying NOT NULL,
    date_commande timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    date_livraison timestamp without time zone,
    drone_latitude numeric(9,6),
    drone_longitude numeric(9,6),
    drone_batterie integer,
    id_commande_metier uuid,
    CONSTRAINT chk_commande_groupe CHECK (((groupe_sanguin)::text = ANY (ARRAY[('A+'::character varying)::text, ('A-'::character varying)::text, ('B+'::character varying)::text, ('B-'::character varying)::text, ('AB+'::character varying)::text, ('AB-'::character varying)::text, ('O+'::character varying)::text, ('O-'::character varying)::text]))),
    CONSTRAINT chk_commande_quantite CHECK ((quantite > 0)),
    CONSTRAINT chk_commande_statut CHECK (((statut_commande)::text = ANY (ARRAY[('EN_ATTENTE'::character varying)::text, ('VALIDEE'::character varying)::text, ('EN_VOL'::character varying)::text, ('LIVREE'::character varying)::text, ('REFUSEE'::character varying)::text]))),
    CONSTRAINT chk_drone_batterie CHECK (((drone_batterie >= 0) AND (drone_batterie <= 100)))
);


ALTER TABLE drone_telemetry.commandes OWNER TO postgres;

--
-- Name: alertes; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.alertes (
    id_alerte uuid DEFAULT gen_random_uuid() NOT NULL,
    id_hopital uuid NOT NULL,
    type_alerte character varying(30) NOT NULL,
    groupe_sanguin character varying(3),
    message text NOT NULL,
    jours_estimes integer,
    lue_hopital boolean DEFAULT false NOT NULL,
    lue_admin boolean DEFAULT false NOT NULL,
    date_creation timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT chk_type_alerte CHECK (((type_alerte)::text = ANY ((ARRAY['RUPTURE_PREVUE'::character varying, 'SURPLUS_A_RISQUE'::character varying, 'PEREMPTION_IMMINENTE'::character varying])::text[])))
);


ALTER TABLE medical_logistics.alertes OWNER TO postgres;

--
-- Name: commande_poches; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.commande_poches (
    id_commande uuid NOT NULL,
    id_poche uuid NOT NULL,
    date_association timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE medical_logistics.commande_poches OWNER TO postgres;

--
-- Name: commandes; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.commandes (
    id_commande uuid DEFAULT gen_random_uuid() NOT NULL,
    id_hopital_demandeur uuid NOT NULL,
    id_hopital_vendeur uuid NOT NULL,
    groupe_sanguin character varying(3) NOT NULL,
    rhesus character varying(1) NOT NULL,
    quantite integer NOT NULL,
    statut character varying(20) DEFAULT 'EN_ATTENTE'::character varying NOT NULL,
    date_commande timestamp without time zone DEFAULT now() NOT NULL,
    valide_par_admin uuid,
    date_validation_admin timestamp without time zone,
    commentaire_admin text,
    drone_assigne character varying(50),
    CONSTRAINT check_groupe_comm CHECK (((groupe_sanguin)::text = ANY (ARRAY[('A'::character varying)::text, ('B'::character varying)::text, ('AB'::character varying)::text, ('O'::character varying)::text]))),
    CONSTRAINT check_quantite_comm CHECK ((quantite > 0)),
    CONSTRAINT check_rhesus_comm CHECK (((rhesus)::text = ANY (ARRAY[('+'::character varying)::text, ('-'::character varying)::text]))),
    CONSTRAINT check_statut_comm CHECK (((statut)::text = ANY (ARRAY[('EN_ATTENTE'::character varying)::text, ('ACCEPTEE'::character varying)::text, ('REFUSEE'::character varying)::text, ('EXPEDIEE'::character varying)::text, ('LIVREE'::character varying)::text, ('ANNULEE'::character varying)::text])))
);


ALTER TABLE medical_logistics.commandes OWNER TO postgres;

--
-- Name: donneurs; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.donneurs (
    id_donneur uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nom character varying(100) NOT NULL,
    groupe_sanguin character varying(5) NOT NULL,
    email character varying(150),
    telephone character varying(150) NOT NULL,
    date_dernier_don date,
    statut_eligibilite boolean DEFAULT true NOT NULL,
    date_creation timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    est_anonyme boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_donneur_groupe CHECK (((groupe_sanguin)::text = ANY (ARRAY[('A+'::character varying)::text, ('A-'::character varying)::text, ('B+'::character varying)::text, ('B-'::character varying)::text, ('AB+'::character varying)::text, ('AB-'::character varying)::text, ('O+'::character varying)::text, ('O-'::character varying)::text])))
);


ALTER TABLE medical_logistics.donneurs OWNER TO postgres;

--
-- Name: historique_dons; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.historique_dons (
    id_don uuid DEFAULT gen_random_uuid() NOT NULL,
    id_donneur uuid NOT NULL,
    id_hopital_prelevement uuid NOT NULL,
    date_don timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    volume_ml integer DEFAULT 450,
    remarques text,
    CONSTRAINT chk_volume CHECK ((volume_ml > 0))
);


ALTER TABLE medical_logistics.historique_dons OWNER TO postgres;

--
-- Name: historique_mouvements; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.historique_mouvements (
    id_mouvement integer NOT NULL,
    id_hopital uuid NOT NULL,
    groupe_sanguin character varying(5) NOT NULL,
    composant character varying(50) NOT NULL,
    quantite_poches integer DEFAULT 1,
    type_mouvement character varying(20) NOT NULL,
    date_mouvement timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE medical_logistics.historique_mouvements OWNER TO postgres;

--
-- Name: historique_mouvements_id_mouvement_seq; Type: SEQUENCE; Schema: medical_logistics; Owner: postgres
--

CREATE SEQUENCE medical_logistics.historique_mouvements_id_mouvement_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE medical_logistics.historique_mouvements_id_mouvement_seq OWNER TO postgres;

--
-- Name: historique_mouvements_id_mouvement_seq; Type: SEQUENCE OWNED BY; Schema: medical_logistics; Owner: postgres
--

ALTER SEQUENCE medical_logistics.historique_mouvements_id_mouvement_seq OWNED BY medical_logistics.historique_mouvements.id_mouvement;


--
-- Name: hopitaux; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.hopitaux (
    id_hopital uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    nom character varying(150) NOT NULL,
    adresse text NOT NULL,
    telephone character varying(20) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL,
    statut character varying(20) DEFAULT 'EN_ATTENTE'::character varying NOT NULL,
    date_creation timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    email character varying(255),
    mot_de_passe character varying(255),
    region character varying(50),
    CONSTRAINT chk_hopital_statut CHECK (((statut)::text = ANY (ARRAY[('EN_ATTENTE'::character varying)::text, ('ACTIF'::character varying)::text, ('DESACTIVE'::character varying)::text])))
);


ALTER TABLE medical_logistics.hopitaux OWNER TO postgres;

--
-- Name: poches_sang; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.poches_sang (
    id_poche uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    id_hopital uuid NOT NULL,
    id_donneur uuid,
    groupe_sanguin character varying(3) NOT NULL,
    composant character varying(30) DEFAULT 'SANG_TOTAL'::character varying NOT NULL,
    volume_ml integer DEFAULT 450 NOT NULL,
    date_collecte date NOT NULL,
    date_peremption date NOT NULL,
    statut character varying(20) DEFAULT 'DISPONIBLE'::character varying NOT NULL,
    CONSTRAINT chk_dates_coherentes CHECK ((date_peremption > date_collecte)),
    CONSTRAINT chk_poche_composant CHECK (((composant)::text = ANY (ARRAY[('SANG_TOTAL'::character varying)::text, ('PLASMA'::character varying)::text, ('PLAQUETTES'::character varying)::text]))),
    CONSTRAINT chk_poche_groupe CHECK (((groupe_sanguin)::text = ANY (ARRAY[('A+'::character varying)::text, ('A-'::character varying)::text, ('B+'::character varying)::text, ('B-'::character varying)::text, ('AB+'::character varying)::text, ('AB-'::character varying)::text, ('O+'::character varying)::text, ('O-'::character varying)::text]))),
    CONSTRAINT chk_poche_statut CHECK (((statut)::text = ANY (ARRAY[('DISPONIBLE'::character varying)::text, ('RESERVE'::character varying)::text, ('UTILISE'::character varying)::text, ('PERIME'::character varying)::text])))
);


ALTER TABLE medical_logistics.poches_sang OWNER TO postgres;

--
-- Name: sos_urgences; Type: TABLE; Schema: medical_logistics; Owner: postgres
--

CREATE TABLE medical_logistics.sos_urgences (
    id_sos uuid DEFAULT gen_random_uuid() NOT NULL,
    id_hopital_demandeur uuid NOT NULL,
    groupe_sanguin character varying(3) NOT NULL,
    rhesus character varying(1) NOT NULL,
    quantite_demandee integer NOT NULL,
    description text,
    statut character varying(20) DEFAULT 'ACTIF'::character varying NOT NULL,
    date_creation timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT check_groupe_sos CHECK (((groupe_sanguin)::text = ANY (ARRAY[('A'::character varying)::text, ('B'::character varying)::text, ('AB'::character varying)::text, ('O'::character varying)::text]))),
    CONSTRAINT check_quantite_sos CHECK ((quantite_demandee > 0)),
    CONSTRAINT check_rhesus_sos CHECK (((rhesus)::text = ANY (ARRAY[('+'::character varying)::text, ('-'::character varying)::text]))),
    CONSTRAINT check_statut_sos CHECK (((statut)::text = ANY (ARRAY[('ACTIF'::character varying)::text, ('RESOLU'::character varying)::text, ('ANNULE'::character varying)::text])))
);


ALTER TABLE medical_logistics.sos_urgences OWNER TO postgres;

--
-- Name: v_stocks; Type: VIEW; Schema: medical_logistics; Owner: postgres
--

CREATE VIEW medical_logistics.v_stocks AS
 SELECT id_hopital,
    groupe_sanguin,
    composant,
    (count(*))::integer AS quantite,
    (COALESCE(sum(volume_ml), (0)::bigint))::integer AS volume_total_ml
   FROM medical_logistics.poches_sang
  WHERE (((statut)::text = 'DISPONIBLE'::text) AND (date_peremption >= CURRENT_DATE))
  GROUP BY id_hopital, groupe_sanguin, composant;


ALTER VIEW medical_logistics.v_stocks OWNER TO postgres;

--
-- Name: historique_mouvements id_mouvement; Type: DEFAULT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.historique_mouvements ALTER COLUMN id_mouvement SET DEFAULT nextval('medical_logistics.historique_mouvements_id_mouvement_seq'::regclass);


--
-- Data for Name: utilisateurs; Type: TABLE DATA; Schema: core_identity; Owner: postgres
--

COPY core_identity.utilisateurs (id_utilisateur, nom, email, mot_de_passe, role, statut_compte, id_hopital, date_inscription) FROM stdin;
568ae10b-c443-429b-b5e3-8c3958d63693	Admin Sandra	sandra@bloodnet.cm	SandraPSS	SUPER_ADMIN	ACTIF	\N	2026-07-13 12:15:06.728939
e3b1f843-c1c8-40a3-883d-6cc441ebb158	Samuel	samuel@bloodnet.com	$2b$10$22H2Y5Q2j369.A/2Jwn8Y.57nJD0QmBBje/VVmLTPIlwp7Xo7M53i	SUPER_ADMIN	ACTIF	\N	2026-07-13 12:25:05.075733
9b451663-6325-43dd-8a35-a98b69c5613a	Admin Hôpital de District	contact@hdd.cm	$2b$10$JN7kk8NJWn5IT0XMX5R2P.YVKhuJzlNkxMgL3UE5aIUS4.zQn6WM.	ADMIN_HOPITAL	ACTIF	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-07-13 13:24:10.449601
e3c26a85-397a-470e-a74b-499be451eb20	Samuel Ayissi	samuel_admin@bloodnet.cm	$2b$10$kVDi61yyiVJnCBEniUwy0u3oQnlGlTP6X5sRG0t6dQjRy/2oiNRJG	SUPER_ADMIN	ACTIF	\N	2026-08-04 00:11:33.61856
\.


--
-- Data for Name: commandes; Type: TABLE DATA; Schema: drone_telemetry; Owner: postgres
--

COPY drone_telemetry.commandes (id_commande, id_demandeur, id_fournisseur, groupe_sanguin, quantite, statut_commande, date_commande, date_livraison, drone_latitude, drone_longitude, drone_batterie, id_commande_metier) FROM stdin;
\.


--
-- Data for Name: alertes; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.alertes (id_alerte, id_hopital, type_alerte, groupe_sanguin, message, jours_estimes, lue_hopital, lue_admin, date_creation) FROM stdin;
\.


--
-- Data for Name: commande_poches; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.commande_poches (id_commande, id_poche, date_association) FROM stdin;
\.


--
-- Data for Name: commandes; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.commandes (id_commande, id_hopital_demandeur, id_hopital_vendeur, groupe_sanguin, rhesus, quantite, statut, date_commande, valide_par_admin, date_validation_admin, commentaire_admin, drone_assigne) FROM stdin;
\.


--
-- Data for Name: donneurs; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.donneurs (id_donneur, nom, groupe_sanguin, email, telephone, date_dernier_don, statut_eligibilite, date_creation, est_anonyme) FROM stdin;
eafda01d-490d-481f-9ce0-f2a0356485ba	Jean Demba	O+	jean.demba@mail.com	+237677123456	\N	t	2026-07-01 13:42:11.793356	f
4ae0cd4a-c89f-4b93-9241-cea71d884353	Jean-Pierre	O-	\N	677654321	\N	t	2026-07-15 14:10:07.557573	f
6b5274c4-e839-4f7a-9675-6beab03eeb9a	Atangana	AB+	\N	677654331	\N	t	2026-07-17 12:27:57.846898	f
514fdc60-66f3-486b-9887-62a2db036dd2	Samuel	A+	\N	677234331	\N	t	2026-07-17 13:05:28.596724	f
e6f15d34-a1f5-4ab3-80bf-7ef931ed2fc8	Donneur anonyme	A-	\N	ANONYME-1785754451900	\N	t	2026-08-03 11:54:11.906665	t
34f1cfb5-9b93-4578-8f49-8ec1573f3363	Donneur anonyme	AB+	\N	ANONYME-1785815030633	\N	t	2026-08-04 04:43:50.646041	t
f0451a4a-06dc-4d4b-a6b3-8b8584e559e5	Donneur anonyme	A+	\N	ANONYME-1786100889865	\N	t	2026-08-07 12:08:09.865597	t
32ef4647-e9bc-421e-9029-5a0728ab56cd	Donneur anonyme	O-	\N	ANONYME-1786355313225	\N	t	2026-08-10 10:48:33.225231	t
b3d0fcb2-7ee3-4c97-83ba-6dcc5acc9a6e	Donneur anonyme	O-	\N	ANONYME-1786354195171	\N	t	2026-08-10 10:29:55.183542	t
\.


--
-- Data for Name: historique_dons; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.historique_dons (id_don, id_donneur, id_hopital_prelevement, date_don, volume_ml, remarques) FROM stdin;
9c62c67d-cb9e-4071-8940-5cc61313c46b	e6f15d34-a1f5-4ab3-80bf-7ef931ed2fc8	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-03 11:54:11.906665+01	350	\N
f31d48be-c4de-4aad-bd10-05f853ce3243	eafda01d-490d-481f-9ce0-f2a0356485ba	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-03 11:54:27.101614+01	350	\N
3efd9bae-5b76-4641-85f0-c5a38dd778ea	eafda01d-490d-481f-9ce0-f2a0356485ba	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-03 11:54:27.104179+01	350	\N
bac42cf9-81d8-4985-9520-c975c595621d	4ae0cd4a-c89f-4b93-9241-cea71d884353	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-04 03:16:43.995557+01	450	\N
61b3d4d4-7d5a-4f7d-a637-b74cb9fca43a	34f1cfb5-9b93-4578-8f49-8ec1573f3363	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-04 04:43:50.646041+01	450	\N
1be1970b-906d-45f6-bdf4-dd41e5c93273	6b5274c4-e839-4f7a-9675-6beab03eeb9a	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-04 04:45:29.969278+01	450	\N
dfd11626-042a-48f0-a8a9-9f96ffaeb001	514fdc60-66f3-486b-9887-62a2db036dd2	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-04 04:55:34.862634+01	450	\N
0c04adb2-9da5-4d2a-9f4d-c154e6e95e9e	f0451a4a-06dc-4d4b-a6b3-8b8584e559e5	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-07 12:08:09.865597+01	400	\N
96f1ab5f-56d5-4adb-a5d6-a05aeebf2178	32ef4647-e9bc-421e-9029-5a0728ab56cd	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-10 10:48:33.225231+01	450	\N
b244b54f-5fda-4342-bafd-23ed41d6a234	b3d0fcb2-7ee3-4c97-83ba-6dcc5acc9a6e	46a00d0e-f644-46fb-8404-f578e8e22ee4	2026-08-10 10:29:55.183542+01	450	\N
\.


--
-- Data for Name: historique_mouvements; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.historique_mouvements (id_mouvement, id_hopital, groupe_sanguin, composant, quantite_poches, type_mouvement, date_mouvement) FROM stdin;
1	46a00d0e-f644-46fb-8404-f578e8e22ee4	O+	SANG_TOTAL	1	ENTREE	2026-08-03 14:15:15.642241
2	46a00d0e-f644-46fb-8404-f578e8e22ee4	B+	SANG_TOTAL	1	ENTREE	2026-08-03 14:16:09.549145
3	46a00d0e-f644-46fb-8404-f578e8e22ee4	B+	SANG_TOTAL	1	ENTREE	2026-08-03 14:16:09.653602
4	46a00d0e-f644-46fb-8404-f578e8e22ee4	O+	SANG_TOTAL	1	SORTIE	2026-08-03 14:19:15.434782
5	46a00d0e-f644-46fb-8404-f578e8e22ee4	AB+	SANG_TOTAL	1	ENTREE	2026-08-04 00:40:09.615383
6	46a00d0e-f644-46fb-8404-f578e8e22ee4	A+	PLASMA	1	ENTREE	2026-08-04 03:52:17.676787
7	46a00d0e-f644-46fb-8404-f578e8e22ee4	A-	SANG_TOTAL	1	ENTREE	2026-08-04 04:42:38.642388
8	46a00d0e-f644-46fb-8404-f578e8e22ee4	A+	SANG_TOTAL	1	ENTREE	2026-08-04 05:04:55.004404
9	46a00d0e-f644-46fb-8404-f578e8e22ee4	A+	SANG_TOTAL	1	SORTIE	2026-08-04 05:05:07.282127
10	46a00d0e-f644-46fb-8404-f578e8e22ee4	A+	SANG_TOTAL	1	SORTIE	2026-08-04 05:05:07.292938
\.


--
-- Data for Name: hopitaux; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.hopitaux (id_hopital, nom, adresse, telephone, latitude, longitude, statut, date_creation, email, mot_de_passe, region) FROM stdin;
2c22747b-a3f6-4f3c-a4e0-1dc6bb4e5211	Hôpital de district	Mvog-betsi	222234015	3.866670	11.516670	EN_ATTENTE	2026-07-13 13:12:10.973114	\N	\N	Centre
46a00d0e-f644-46fb-8404-f578e8e22ee4	Hôpital de district	Mvog-betsi	222234015	3.866670	11.516670	ACTIF	2026-07-13 13:09:21.777456	\N	\N	Centre
7fdbdb21-fae7-4365-98d6-2a16fc7a2ac4	CHU	Yaounde 	+237222479803	3.862710	11.496140	ACTIF	2026-07-17 13:15:16.574041	\N	\N	Centre
\.


--
-- Data for Name: poches_sang; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.poches_sang (id_poche, id_hopital, id_donneur, groupe_sanguin, composant, volume_ml, date_collecte, date_peremption, statut) FROM stdin;
ae6e9fbb-c5d6-454b-a7da-2a7b02b4639f	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	B+	SANG_TOTAL	350	2026-07-23	2026-09-03	DISPONIBLE
edb20e93-76ab-4c69-af95-5d702ee20594	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	AB+	SANG_TOTAL	350	2026-07-24	2026-09-04	DISPONIBLE
26bbde9d-034f-4e42-abed-d20f29756e77	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	AB+	SANG_TOTAL	450	2026-07-23	2026-09-03	DISPONIBLE
fef5200d-ac93-4756-a009-77f9d4bfaf64	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	O-	SANG_TOTAL	351	2026-07-24	2026-09-04	DISPONIBLE
3060d2a2-92d1-423b-bd17-2504fb6ce241	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A-	SANG_TOTAL	350	2026-08-03	2026-09-14	DISPONIBLE
7d18fa05-d4e4-42a5-9eba-112197e1d1dd	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	O+	SANG_TOTAL	350	2026-08-03	2026-09-14	DISPONIBLE
f46e9c75-58dd-46ad-ba31-01775cd070e7	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	O+	SANG_TOTAL	350	2026-08-03	2026-09-14	DISPONIBLE
faf82c1e-c7a1-446c-b340-c9acbbb04d1e	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	O+	SANG_TOTAL	340	2026-08-03	2026-09-14	DISPONIBLE
f90c2f0a-fa9b-4f97-a197-c943b37e17bf	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	B+	SANG_TOTAL	340	2026-08-03	2026-09-14	DISPONIBLE
07da0e9c-6622-4db1-8e22-9219af068eaf	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	B+	SANG_TOTAL	340	2026-08-03	2026-09-14	DISPONIBLE
014f0c61-6e1e-4115-9839-1a6e263f11cf	46a00d0e-f644-46fb-8404-f578e8e22ee4	4ae0cd4a-c89f-4b93-9241-cea71d884353	O+	SANG_TOTAL	450	2026-07-16	2026-08-27	UTILISE
576c9bd7-eb58-4f8e-92d0-560edc03a322	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	AB+	SANG_TOTAL	450	2026-08-04	2026-09-15	DISPONIBLE
36fe62d2-95e0-4ad1-8064-85911115e89c	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	O-	SANG_TOTAL	450	2026-08-04	2026-09-15	DISPONIBLE
4e1a7dfa-2165-4883-a6cc-58d1fb7c2710	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A+	PLASMA	450	2026-08-04	2027-08-04	DISPONIBLE
2bae2efc-a1c6-4eeb-bb28-46724068c0d0	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A-	SANG_TOTAL	450	2026-08-05	2026-09-16	DISPONIBLE
df65c4b4-a3e5-40dd-a656-24ea8b3e0dd2	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	AB+	SANG_TOTAL	450	2026-08-04	2026-09-15	DISPONIBLE
b4ec22be-35e0-4aa7-95bd-214568712e71	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	AB+	SANG_TOTAL	450	2026-08-04	2026-09-15	DISPONIBLE
9af7ab8a-9330-4d95-8b00-8d405b7faa7d	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A+	SANG_TOTAL	450	2026-08-04	2026-09-15	DISPONIBLE
68e58913-3c08-4e31-95cd-d840e5087f79	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A+	SANG_TOTAL	450	2026-08-05	2026-09-16	DISPONIBLE
f4f10f9e-35df-4ff0-859e-539a0b75e210	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A+	SANG_TOTAL	450	2026-07-16	2026-08-27	UTILISE
7d42a3fc-d3aa-4f90-8893-62d5b81b51f0	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A+	SANG_TOTAL	450	2026-07-16	2026-08-27	UTILISE
8da0ce51-75e9-4607-8387-fff816fe50bb	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	A+	SANG_TOTAL	400	2026-08-07	2026-09-18	DISPONIBLE
9f416d7e-1e58-401c-9b4a-368dd8fd1f5f	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	O-	SANG_TOTAL	450	2026-08-10	2026-09-21	DISPONIBLE
dae3bacb-9a28-482b-8443-705048c27ab0	46a00d0e-f644-46fb-8404-f578e8e22ee4	\N	O-	SANG_TOTAL	450	2026-08-10	2026-09-21	DISPONIBLE
\.


--
-- Data for Name: sos_urgences; Type: TABLE DATA; Schema: medical_logistics; Owner: postgres
--

COPY medical_logistics.sos_urgences (id_sos, id_hopital_demandeur, groupe_sanguin, rhesus, quantite_demandee, description, statut, date_creation) FROM stdin;
f0c9993c-2df7-4498-a7d4-36f076afaa69	46a00d0e-f644-46fb-8404-f578e8e22ee4	O	-	5	Urgence vitale suite à un accident de la route majeur. Besoin immédiat de poches O-.	ACTIF	2026-07-16 03:02:13.530292
3c54ba50-3fbe-4319-ba1d-d5a7470c27b4	46a00d0e-f644-46fb-8404-f578e8e22ee4	O	-	5	Urgence vitale suite à un accident de la route majeur. Besoin immédiat de poches O-.	ACTIF	2026-07-16 03:02:31.053639
2d71a984-9d6d-4477-bb4a-10a16e6604be	46a00d0e-f644-46fb-8404-f578e8e22ee4	O	-	5	Urgence vitale suite à un accident de la route majeur. Besoin immédiat de poches O-.	ACTIF	2026-07-16 03:04:33.172645
\.


--
-- Name: historique_mouvements_id_mouvement_seq; Type: SEQUENCE SET; Schema: medical_logistics; Owner: postgres
--

SELECT pg_catalog.setval('medical_logistics.historique_mouvements_id_mouvement_seq', 10, true);


--
-- Name: utilisateurs utilisateurs_email_key; Type: CONSTRAINT; Schema: core_identity; Owner: postgres
--

ALTER TABLE ONLY core_identity.utilisateurs
    ADD CONSTRAINT utilisateurs_email_key UNIQUE (email);


--
-- Name: utilisateurs utilisateurs_pkey; Type: CONSTRAINT; Schema: core_identity; Owner: postgres
--

ALTER TABLE ONLY core_identity.utilisateurs
    ADD CONSTRAINT utilisateurs_pkey PRIMARY KEY (id_utilisateur);


--
-- Name: commandes commandes_pkey; Type: CONSTRAINT; Schema: drone_telemetry; Owner: postgres
--

ALTER TABLE ONLY drone_telemetry.commandes
    ADD CONSTRAINT commandes_pkey PRIMARY KEY (id_commande);


--
-- Name: alertes alertes_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.alertes
    ADD CONSTRAINT alertes_pkey PRIMARY KEY (id_alerte);


--
-- Name: commande_poches commande_poches_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.commande_poches
    ADD CONSTRAINT commande_poches_pkey PRIMARY KEY (id_commande, id_poche);


--
-- Name: commandes commandes_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.commandes
    ADD CONSTRAINT commandes_pkey PRIMARY KEY (id_commande);


--
-- Name: donneurs donneurs_email_key; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.donneurs
    ADD CONSTRAINT donneurs_email_key UNIQUE (email);


--
-- Name: donneurs donneurs_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.donneurs
    ADD CONSTRAINT donneurs_pkey PRIMARY KEY (id_donneur);


--
-- Name: donneurs donneurs_telephone_key; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.donneurs
    ADD CONSTRAINT donneurs_telephone_key UNIQUE (telephone);


--
-- Name: historique_dons historique_dons_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.historique_dons
    ADD CONSTRAINT historique_dons_pkey PRIMARY KEY (id_don);


--
-- Name: historique_mouvements historique_mouvements_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.historique_mouvements
    ADD CONSTRAINT historique_mouvements_pkey PRIMARY KEY (id_mouvement);


--
-- Name: hopitaux hopitaux_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.hopitaux
    ADD CONSTRAINT hopitaux_pkey PRIMARY KEY (id_hopital);


--
-- Name: poches_sang poches_sang_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.poches_sang
    ADD CONSTRAINT poches_sang_pkey PRIMARY KEY (id_poche);


--
-- Name: sos_urgences sos_urgences_pkey; Type: CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.sos_urgences
    ADD CONSTRAINT sos_urgences_pkey PRIMARY KEY (id_sos);


--
-- Name: idx_commandes_statut; Type: INDEX; Schema: drone_telemetry; Owner: postgres
--

CREATE INDEX idx_commandes_statut ON drone_telemetry.commandes USING btree (statut_commande);


--
-- Name: idx_drone_commande_metier; Type: INDEX; Schema: drone_telemetry; Owner: postgres
--

CREATE INDEX idx_drone_commande_metier ON drone_telemetry.commandes USING btree (id_commande_metier);


--
-- Name: idx_alertes_date; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE INDEX idx_alertes_date ON medical_logistics.alertes USING btree (date_creation DESC);


--
-- Name: idx_alertes_hopital; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE INDEX idx_alertes_hopital ON medical_logistics.alertes USING btree (id_hopital, lue_hopital);


--
-- Name: idx_alertes_unicite_jour; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE UNIQUE INDEX idx_alertes_unicite_jour ON medical_logistics.alertes USING btree (id_hopital, type_alerte, groupe_sanguin, ((date_creation)::date));


--
-- Name: idx_commande_poches_commande; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE INDEX idx_commande_poches_commande ON medical_logistics.commande_poches USING btree (id_commande);


--
-- Name: idx_commande_poches_poche; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE INDEX idx_commande_poches_poche ON medical_logistics.commande_poches USING btree (id_poche);


--
-- Name: idx_donneurs_eligibilite; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE INDEX idx_donneurs_eligibilite ON medical_logistics.donneurs USING btree (date_dernier_don, statut_eligibilite);


--
-- Name: idx_historique_donneur; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE INDEX idx_historique_donneur ON medical_logistics.historique_dons USING btree (id_donneur, date_don DESC);


--
-- Name: idx_poches_recherche; Type: INDEX; Schema: medical_logistics; Owner: postgres
--

CREATE INDEX idx_poches_recherche ON medical_logistics.poches_sang USING btree (id_hopital, groupe_sanguin, statut);


--
-- Name: utilisateurs fk_utilisateur_hopital; Type: FK CONSTRAINT; Schema: core_identity; Owner: postgres
--

ALTER TABLE ONLY core_identity.utilisateurs
    ADD CONSTRAINT fk_utilisateur_hopital FOREIGN KEY (id_hopital) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE SET NULL;


--
-- Name: commandes commandes_id_commande_metier_fkey; Type: FK CONSTRAINT; Schema: drone_telemetry; Owner: postgres
--

ALTER TABLE ONLY drone_telemetry.commandes
    ADD CONSTRAINT commandes_id_commande_metier_fkey FOREIGN KEY (id_commande_metier) REFERENCES medical_logistics.commandes(id_commande) ON DELETE CASCADE;


--
-- Name: commandes fk_commande_demandeur; Type: FK CONSTRAINT; Schema: drone_telemetry; Owner: postgres
--

ALTER TABLE ONLY drone_telemetry.commandes
    ADD CONSTRAINT fk_commande_demandeur FOREIGN KEY (id_demandeur) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE CASCADE;


--
-- Name: commandes fk_commande_fournisseur; Type: FK CONSTRAINT; Schema: drone_telemetry; Owner: postgres
--

ALTER TABLE ONLY drone_telemetry.commandes
    ADD CONSTRAINT fk_commande_fournisseur FOREIGN KEY (id_fournisseur) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE SET NULL;


--
-- Name: alertes alertes_id_hopital_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.alertes
    ADD CONSTRAINT alertes_id_hopital_fkey FOREIGN KEY (id_hopital) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE CASCADE;


--
-- Name: commande_poches commande_poches_id_commande_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.commande_poches
    ADD CONSTRAINT commande_poches_id_commande_fkey FOREIGN KEY (id_commande) REFERENCES medical_logistics.commandes(id_commande) ON DELETE CASCADE;


--
-- Name: commande_poches commande_poches_id_poche_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.commande_poches
    ADD CONSTRAINT commande_poches_id_poche_fkey FOREIGN KEY (id_poche) REFERENCES medical_logistics.poches_sang(id_poche) ON DELETE CASCADE;


--
-- Name: commandes commandes_id_hopital_demandeur_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.commandes
    ADD CONSTRAINT commandes_id_hopital_demandeur_fkey FOREIGN KEY (id_hopital_demandeur) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE CASCADE;


--
-- Name: commandes commandes_id_hopital_vendeur_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.commandes
    ADD CONSTRAINT commandes_id_hopital_vendeur_fkey FOREIGN KEY (id_hopital_vendeur) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE CASCADE;


--
-- Name: commandes commandes_valide_par_admin_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.commandes
    ADD CONSTRAINT commandes_valide_par_admin_fkey FOREIGN KEY (valide_par_admin) REFERENCES core_identity.utilisateurs(id_utilisateur);


--
-- Name: historique_mouvements fk_hopital; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.historique_mouvements
    ADD CONSTRAINT fk_hopital FOREIGN KEY (id_hopital) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE CASCADE;


--
-- Name: poches_sang fk_poche_donneur; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.poches_sang
    ADD CONSTRAINT fk_poche_donneur FOREIGN KEY (id_donneur) REFERENCES medical_logistics.donneurs(id_donneur) ON DELETE SET NULL;


--
-- Name: poches_sang fk_poche_hopital; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.poches_sang
    ADD CONSTRAINT fk_poche_hopital FOREIGN KEY (id_hopital) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE CASCADE;


--
-- Name: historique_dons historique_dons_id_donneur_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.historique_dons
    ADD CONSTRAINT historique_dons_id_donneur_fkey FOREIGN KEY (id_donneur) REFERENCES medical_logistics.donneurs(id_donneur) ON DELETE CASCADE;


--
-- Name: historique_dons historique_dons_id_hopital_prelevement_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.historique_dons
    ADD CONSTRAINT historique_dons_id_hopital_prelevement_fkey FOREIGN KEY (id_hopital_prelevement) REFERENCES medical_logistics.hopitaux(id_hopital);


--
-- Name: sos_urgences sos_urgences_id_hopital_demandeur_fkey; Type: FK CONSTRAINT; Schema: medical_logistics; Owner: postgres
--

ALTER TABLE ONLY medical_logistics.sos_urgences
    ADD CONSTRAINT sos_urgences_id_hopital_demandeur_fkey FOREIGN KEY (id_hopital_demandeur) REFERENCES medical_logistics.hopitaux(id_hopital) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict 9FjG3JnQZcOfjx3Bzy4TSLHuCBuo5fv9sgSachF3gvKDKlvH7oYs8idb8SDPLPg

