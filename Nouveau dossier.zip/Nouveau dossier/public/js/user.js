// public/js/users.js (Code exécuté par le navigateur)

async function createHospitalUser(userData) {
    const token = localStorage.getItem('bloodnet_token');

    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({
                nom: userData.nom,
                email: userData.email,
                password: userData.password,
                role: userData.role || 'AGENT_HOPITAL'
            })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message);

        return data;
    } catch (error) {
        console.error("Erreur création utilisateur :", error);
        throw error;
    }
}